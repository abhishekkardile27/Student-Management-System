package in.sm.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.sm.entity.Student;
import in.sm.repository.StudentRepository;
import in.sm.studentservice.StudentService;



@Service
public class serviceImpl implements StudentService {

    @Autowired
    private StudentRepository repo;

    @Override
    public List<Student> getAllStudents() {
        return repo.findAll();
    }

    @Override
    public void saveStudent(Student student) {
        repo.save(student);
    }

    @Override
    public Student getStudentById(int id) {
        return repo.findById(id).orElse(null);
    }

    @Override
    public void deleteStudentById(int id) {
        repo.deleteById(id);
    }

	@Override
	public void saveStudent1(Student student) {
		// TODO Auto-generated method stub
		
	}
}