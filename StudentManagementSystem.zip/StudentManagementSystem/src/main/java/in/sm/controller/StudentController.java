package in.sm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import in.sm.entity.Student;
import in.sm.studentservice.StudentService;

@Controller
public class StudentController {

    @Autowired
    private StudentService service;

    // display list
    @GetMapping("/")
    public String viewHomePage(Model model) {

        model.addAttribute("listStudents", service.getAllStudents());

        return "index";
    }

    // open add form
    @GetMapping("/showNewStudentForm")
    public String showNewStudentForm(Model model) {

        Student student = new Student();

        model.addAttribute("student", student);

        return "new_student";
    }

    // save student
    @PostMapping("/saveStudent")
    public String saveStudent(@ModelAttribute("student") Student student) {

        service.saveStudent(student);

        return "redirect:/";
    }

    // update student
    @GetMapping("/showFormForUpdate/{id}")
    public String showFormForUpdate(@PathVariable(value = "id") int id,
                                    Model model) {

        Student student = service.getStudentById(id);

        model.addAttribute("student", student);

        return "update_student";
    }

    // delete student
    @GetMapping("/deleteStudent/{id}")
    public String deleteStudent(@PathVariable(value = "id") int id) {

        service.deleteStudentById(id);

        return "redirect:/";
    }
}