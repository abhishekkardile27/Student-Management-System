package in.sm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import in.sm.entity.Student;


public interface StudentRepository extends JpaRepository<Student, Integer> {

}