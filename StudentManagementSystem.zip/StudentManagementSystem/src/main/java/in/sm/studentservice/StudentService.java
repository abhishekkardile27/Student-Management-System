package in.sm.studentservice;

import java.util.List;

import in.sm.entity.Student;



public interface StudentService {

    public List<Student> getAllStudents();

    public void saveStudent1(Student student);

    public Student getStudentById(int id);

    public void deleteStudentById(int id);

	public void saveStudent(Student student);
}